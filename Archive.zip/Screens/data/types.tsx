export default [
  {
    id: '0',
    type: 'BeetleX',
    price: 22,
    duration: 45,
    image:'http://www.pngall.com/wp-content/uploads/2018/04/Sedan-PNG-Clipart.png',
  },
  {
    id: '1',
    type: 'BComfort',
    price: 27,
    duration: 30,
    image:'http://www.pngall.com/wp-content/uploads/2018/04/Sedan-Free-Download-PNG.png',
  },
  // {
  //   id: '2',
  //   type: 'BeetleXL',
  //   price: 36,
  //   duration: 27,
  //   image:'https://reactnativecode.com/wp-content/uploads/2017/05/react_thumb_install.png',
  // },
]
